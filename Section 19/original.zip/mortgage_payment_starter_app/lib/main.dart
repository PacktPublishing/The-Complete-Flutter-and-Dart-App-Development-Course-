import 'package:flutter/material.dart';
import 'package:mortgage_payment_starter_app/ui/mortgage_app.dart';


void main() => runApp(new MaterialApp(
  home: MortgageApp(),
));